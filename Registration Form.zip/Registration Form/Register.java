import java.util.*;
	class Student {
    	int id, age, tenth, twelth;
	long ph;
   	String name, add, email, course;

    	public Student(int id, String name,String add, int age, int tenth, int twelth, String email, long ph, String course) {
       			 this.id = id;
      			 this.name = name;
     		         this.add = add;
     			 this.age = age;
			 this.tenth = tenth;
        		 this.twelth = twelth;
        		 this.email = email;
        		 this.ph = ph;
        		 this.course = course;
   	 }

    	 public String toString() {
				System.out.println();
				return id + " | " + name + " | " + add +" | " + age + " | " + tenth + " | " + twelth + " | " + email + " | " + ph + " | " + course+"\n";
   	 }
	}
	class Valid{
    		public static long getPhone(Scanner sc)  {
		    long ph = 0;
		    int cho=0;
    		    while (cho<3) {
			cho++;
        		System.out.print("Enter Phone No: ");
        		String phoneInput = sc.nextLine();
        		if(phoneInput.matches("[6-9][0-9]{9}"))
			{
            			ph = Long.parseLong(phoneInput);
            			return ph; 
        		}
			else
			{
            			System.out.println("Invalid mobile number re-enter your mobile number choice out of " + cho +" of 3.");
        		}
    		    } 
		    return -1;
		    
    		}
    		public static String getEmail(Scanner sc) {
		int cho=0;
		String email;
		while (cho<3) {
            		cho++;
			System.out.print("Enter Email Id: ");
            		email = sc.nextLine().trim();
            		if(email.endsWith("@gmail.com")) {
                		return email;     
          		}else{
               			 System.out.println("Invalid email (Must end with @gmail.com) re-enter your Email choice out of " + cho +" of 3.");
            		}
			
        	}
		return null;  
    		}
		public static int ageCheck(Scanner sc) {
		int cho=0;
		while (cho<3) {
			cho++;
            		System.out.print("Enter Your age: ");
            		int age=sc.nextInt();
            		if(age>=18) {
                		return age;     
          		}else{
               			 System.out.println("Only Your age is above 18 re-enter your age choice out of " + cho +" of 3.");
            		}
			
        	}
		return -1;  
		}
		public static int tenthMark(Scanner sc) {
		int cho=0;
		while (cho<3) {
			cho++;
            		System.out.print("Enter Your 10th Mark: ");
            		int tenth=sc.nextInt();
            		if(tenth>=175) {
                		return tenth;     
          		}else{
               			 System.out.println("Minimm Marks is 175 re-enter Your 10th mark choice out of " + cho +" of 3.");
            		}
			
			
        	}
		return -1;  
		}
		public static int twelthMark(Scanner sc) {
		int cho=0;
		while (cho<3) {
            		System.out.print("Enter Your 12th Mark: ");
            		int twelth=sc.nextInt();
			cho++;
            		if(twelth>=210) {
                		return twelth;     
          		}else{
               			 System.out.println("Minimm Marks is 210 re-enter your 12th Mark choice out of " + cho +" of 3.");
            		}
        	}          
		return -1;   
		}
	}
	class Regis{
		private static Scanner sc=new Scanner(System.in);
		private static Map<Integer,Student> hs=new HashMap<>();

	public static void regist(){
		
		System.out.print("Enter Your Student ID :");
		int id=sc.nextInt();
		
		if(hs.containsKey(id)){
			System.out.print("Id Already Exits");
			return;
		}
		System.out.print("Enter Your Name :");
		sc.nextLine();
		String name=sc.nextLine();
		System.out.print("Enter Address :");
		String add=sc.nextLine();
		
		int age=Valid.ageCheck(sc);
		if (age == -1) {
        		System.out.println("Try Again from Main Menu.");
        		return;  
    		    }
		int tenth = Valid.tenthMark(sc);
		if ( tenth== -1) {
        		System.out.println("Try Again from Main Menu.");
        		return;  
    		    }
		int twelth= Valid.twelthMark(sc);
		if (twelth == -1) {
        		System.out.println("Try Again from Main Menu.");
        		return;  
    		    }
		sc.nextLine();
		String email=Valid.getEmail(sc);
		if (email == null) {
        		System.out.println("Try Again from Main Menu.");
        		return;  
    		    }
		long ph = Valid.getPhone(sc);
		if (ph == -1) {
        		System.out.println("Try Again from Main Menu.");
        		return;  
    		    }
		System.out.print("Prefered Courses :");
		String course=sc.nextLine();
		System.out.println();
		System.out.println("Register SuccessFully");
		Student s=new Student(id,name,add,age,tenth,twelth,email,ph,course);
		hs.put(id,s);
		return;
	}

	public static void modify(){
		System.out.println();
		if(hs.isEmpty()){
			System.out.print("No Record Found ");
			return;
		}
		System.out.print("Enter your Id :");
		int alter=sc.nextInt();
		boolean a=hs.containsKey(alter);
		if(a!=true){
			System.out.print("Id not Found");
		}
		else{
		boolean exit=false;
		while(!exit){
		System.out.println();
		System.out.println("1: Name");
		System.out.println("2: Address");
		System.out.println("3: Age");
		System.out.println("4: E-mail");
		System.out.println("5: Phone No");
		System.out.println("6: Mark");
		System.out.println("7: prefered Course");
		System.out.println("8:Exit");
		int ch;
		System.out.print("Enter You want to Modify :");
		ch= sc.nextInt();
		Student s=hs.get(alter);
		switch(ch){
				case 1:
					System.out.print("Enter your Name :");
					sc.nextLine();
					String mname=sc.nextLine();
					s.name=mname;
					System.out.println("Modification Successfully");
					break;
				case 2:
					System.out.print("Enter your Address :");
					sc.nextLine();
					String address=sc.nextLine();
					s.add=address;
					System.out.println("Modification Successfully");
					break;
				case 3:
					
					int age=Valid.ageCheck(sc);
					if (age == -1) {
        					System.out.println("Try Again from Main Menu.");
        					return;  
    		    			}
					s.age=age;
					System.out.println("Modification Successfully");
					break;
				case 4:
					String email=Valid.getEmail(sc);
					if (email == null) {
        					System.out.println("Try Again from Main Menu.");
        					return;  
    		    			}
					s.email=email;
					System.out.println("Modification Successfully");
					break;
				case 5:
					long ph =Valid.getPhone(sc);
					if (ph == -1) {
        					System.out.println("Try Again from Main Menu.");
        					return;  
    		    			}
					s.ph=ph;
					System.out.println("Modification Successfully");
					break;
				case 6:
				
					System.out.println("1: 10th Mark ");
					System.out.println("2: 12th Mark ");
					System.out.print("You want to change 10th or 12th Mark :");
					int choice=sc.nextInt();
					switch(choice){
						case 1:
							int tenth= Valid.tenthMark(sc);	
							if (tenth == -1) {
        							System.out.println("Try Again from Main Menu.");
        							return;  
    		    					}
							s.tenth=tenth;
							System.out.println("Modification Successfully");
							break;
						case 2:
							int twelth=Valid.twelthMark(sc);	
							if (twelth == -1) {
        							System.out.println("Try Again from Main Menu.");
        							return;  
    		    					}
							s.twelth=twelth;	
							System.out.println("Modification Successfully");
							break;
						default: 
							System.out.println("Enter Your Option ( 1 & 2)");
					}
					break;
					
						
				case 7:
					System.out.println( );
					String[] cor=new String[]{"BCA","BBA","BCOM","BCOM CA","BE CIVIL"};
					for (String sh : cor) {
   						 System.out.println(sh);
					}				
					System.out.print("Enter your Course Prefered : ");
					sc.nextLine();
					String sub=sc.nextLine();
					s.course=sub;
					System.out.println("Modification Successfully");
					break;
				case 8:
					exit=true;
				
				}
			}
		}	
	}
	
	public static void delete(){
		if(hs.isEmpty()){
			System.out.print("No Record Found ");
		}
		System.out.print("Enter ID to Delete Student Detail :");
		int ids=sc.nextInt();
		boolean a=hs.containsKey(ids);
		if(a!=true){
			System.out.print("Id not Found");
		}
		else{
			Student s=hs.remove(ids);
			System.out.print("Details Removed ");
		}
		
		
	}
	public static void show(){
		if(hs.isEmpty()){
			System.out.print("No Record Found ");
			return;
		}
		for(Student s:hs.values())
		{
			System.out.print(s);
		}
	}
	public static void search(){
		if(hs.isEmpty()){
			System.out.print("No Record Found ");
			return;
		}
		System.out.print("Enter Id : ");
		int sear=sc.nextInt();
		Student s=hs.get(sear);
		if(s!=null){
			System.out.print("Your Detail is :"+s);
		}
		else{
			System.out.print("Invalid Id ");
			return;
		}
	}

}	
	
public class Register{
		
	public static void main(String[] args){
		System.out.println("\t\t College Registration Form ");
		System.out.println("\t\t ~~~~~~~ ~~~~~~~~~~~~ ~~~~ ");
		Scanner sc=new Scanner(System.in);
		boolean exit=false;
		System.out.println();
		while(!exit)
		{
		System.out.println("Select Your Options : ");
		System.out.println("1: Registration");
		System.out.println("2: Modify");
		System.out.println("3: Search");
		System.out.println("4: Delete");
		System.out.println("5: View Student Rigstration");
		System.out.println("6: Exit");
		int ch;
		System.out.println();
		System.out.print("Enter The Option :");
		ch= sc.nextInt();
			switch(ch){
				case 1->Regis.regist();
				case 2->Regis.modify();
				case 3->Regis.search();
				case 4->Regis.delete();
				case 5-> Regis.show();
				case 6-> exit=true;
				default->{return;}
    
			}
		}
			
		sc.close();		
	}
}